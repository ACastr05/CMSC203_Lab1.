import java.util.Scanner;
 
public class MovieDriverTask2 {
 
	public static void main(String[] args) {
 
		Scanner keyboard = new Scanner(System.in);
 
		String continueResponse;
 
		do {
			
			Movie movie = new Movie();
 
			
			System.out.print("Enter the movie title: ");
		
			String title = keyboard.nextLine();
		
			movie.setTitle(title);
 
			System.out.print("Enter the movie rating: ");
	
			String rating = keyboard.nextLine();
	
			movie.setRating(rating);
 
			System.out.print("Enter the number of tickets sold: ");

			int soldTickets = keyboard.nextInt();

			movie.setSoldTickets(soldTickets);
 
			keyboard.nextLine();
 
			System.out.println(movie.toString());
 
			System.out.print("Would you like to enter another movie? (yes/no): ");
			continueResponse = keyboard.nextLine();
 
		} while (continueResponse.equalsIgnoreCase("yes"));
 
		System.out.println("Goodbye!");
 
		keyboard.close();
	}
}
